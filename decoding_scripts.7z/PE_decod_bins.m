function [bins_trials_deco]=PE_decod_bins(data_decoding_ERP, predicted_all, names, data_folder, bins_trials, two_types)
%decodability_negative_PE = NaN(12,2,length(names));
%decodability_positive_PE = NaN(12,2,length(names));
bins_trials_deco=bins_trials;
if two_types==1
    bins_trials_deco.decodability_negative_PE = NaN(height(bins_trials_deco),1);
    bins_trials_deco.decodability_positive_PE = NaN(height(bins_trials_deco),1);
else
    bins_trials_deco.decodability_PE = NaN(height(bins_trials_deco),1);
end
for i=1:length(names)    
    clear('bins_deco', 'RPEs_single', 'X', 'Y')
    name=names{i};
    %RPEs_single=readtable(strcat(fullfile(data_folder,['subject_' name], ['RPEs_single_' name, '.csv'])));
    RPEs_bins=readtable(strcat(fullfile(data_folder,['subject_' name], ['RPEs_bins_' name, '.csv'])));
    bins_deco = RPEs_bins.RPEs;
    bins_deco = bins_deco(find(RPEs_bins.block<1000));
    X = squeeze(data_decoding_ERP(i,1:length(bins_deco),:));
    bins_deco(:,2)=NaN;
        for b = 1:length(bins_deco)
            bins_trials_subject = bins_trials_deco(bins_trials_deco.subject==str2double(name),:);
            bin = find((bins_trials_subject.from_trial<=b & bins_trials_subject.to_trial>=b));
            if ~isempty(bin)
                bins_deco(b,2)=bin-1;
            else 
                bins_deco(b,2)=NaN;
            end
        end
    %goodtrials_X= find(~isnan(X(:,1)));%TF
    goodtrials_X=find(sum(isnan(X),2)==0);%ERP
    goodtrials_Y= find(~isnan(bins_deco(:,1)));
    decode_trials = intersect(goodtrials_X,goodtrials_Y);
    bins_deco = bins_deco(decode_trials, :);
    bins_deco(:,3)=predicted_all(1:length(bins_deco),i);
    unique_bins=unique(bins_deco(:,2));
        for t=1:length(unique_bins)
           if two_types==1
                z=unique_bins(t);
                f=intersect(find(bins_trials_deco.subject==str2double(name)),find(bins_trials_deco.bin==z));
                positive_PE_bin = bins_deco(find(bins_deco(:,2)==z & bins_deco(:,1)>0),:);
                negative_PE_bin = bins_deco(find(bins_deco(:,2)==z & bins_deco(:,1)<0),:);
                if (length(positive_PE_bin)>1 && length(negative_PE_bin)>1)
                    deco_pos_PE_bin = corr(positive_PE_bin(:,1),positive_PE_bin(:,3));
                    deco_neg_PE_bin = corr(negative_PE_bin(:,1),negative_PE_bin(:,3));                
                    bins_trials_deco.decodability_positive_PE(f) = deco_pos_PE_bin;
                    bins_trials_deco.decodability_negative_PE(f) = deco_neg_PE_bin; 
                else
                    bins_trials_deco.decodability_positive_PE(f) = NaN;
                    bins_trials_deco.decodability_negative_PE(f) = NaN;
                end                    
           else
                PE_bin = bins_deco(find(bins_deco(:,2)==z),:);
                deco_PE_bin = corr(PE_bin(:,1),PE_bin(:,3));
                bins_trials_deco.decodability_PE(f) = deco_PE_bin;                
           end
        end       
end
end