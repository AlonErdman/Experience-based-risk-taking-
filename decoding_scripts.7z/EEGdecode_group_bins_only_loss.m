function [decodability_all, pval_all, predicted_all, regs_all]=EEGdecode_group_bins(names, data_decoding, data_folder)
decodability_all = NaN(length(names),1);
pval_all = NaN(length(names),1);
predicted_all = NaN(3000,length(names));
regs_all = NaN(5,3,length(names));
for i=1:length(names)
    clear('decodability', 'pval', 'predicted', 'regs')
    name=names{i};
    %RPEs_single=readtable(strcat(fullfile(data_folder,['subject_' name], ['RPEs_single_' name, '.csv'])));
    if exist(strcat(fullfile(data_folder,['subject_' name])), 'dir') == 7
    RPEs_bins=readtable(strcat(fullfile(data_folder,['subject_' name], ['RPEs_bins_' name, '.csv'])));
    trials_info=load(strcat(fullfile(data_folder,['subject_' name], [name '_outcome_trials', '.mat'])));
    outcome=trials_info.trial_block_outcome_feedback(:,3);
    outcome = outcome(325:end);
    loss_trials = find(outcome<0);
    Y = RPEs_bins.RPEs;
    Y = Y(find(RPEs_bins.block<1000));
    X = squeeze(data_decoding(i,1:length(Y),:));    
    goodtrials_X=find(sum(isnan(X),2)==0);
    goodtrials_Y= find(~isnan(Y));
    decode_trials = intersect(intersect(goodtrials_X, goodtrials_Y), loss_trials);
    %decode_trials = intersect(goodtrials_X,goodtrials_Y);
    Y = Y(decode_trials);
    X = X(decode_trials,:);
    X = zscore(X);
    [decodability, pval, predicted, regs] = EEGdecode(Y, X);
    decodability_all(i) = decodability;
    pval_all(i) = pval;
    predicted_all(1:length(predicted),i) = predicted;
    regs_all(:,:,i)=regs;
    disp(i)
    disp(pval)
    end
end
end