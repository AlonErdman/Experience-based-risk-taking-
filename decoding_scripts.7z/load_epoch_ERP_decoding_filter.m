function [data_decoding_ERP] = load_epoch_ERP_decoding_filter(names, data_folder, sampling_rate, feedback_time)
N_trials =4032;
decoding_trial_length = 180; %180 if 51
data_decoding_ERP = NaN(length(names),N_trials,decoding_trial_length);
for i =1:length(names)
    clear('epoch_data', 'epoch_data_temp');
    name=names{i};
    filename_EEG = dir(strcat(fullfile(data_folder,['subject_' name]),['\' name '_EEG.mat']));
    load(strcat(filename_EEG(1).folder,'\',filename_EEG(1).name), 'epoch_data_feedback')
    epoch_data = epoch_data_feedback;
    epoch_data(1:324, :, :) = []; %remove practice trials
    epoch_data(:, 1:256, :) = []; %remove the first 256 samples that are needed only for TF analysis
    [epoch_data_freq_filtered] = ERP_filter(epoch_data);
    epoch_data = epoch_data_freq_filtered;
    epoch_data_temp = epoch_data;    
    epoch_data_temp(:,:,2:3)=[];
    epoch_data_temp= squeeze(mean(epoch_data_temp,3,'omitnan')); %average temporal electrodes
    epoch_data_temp = smoothdata(epoch_data_temp,2,'movmean' ,10, 'omitnan');
    epoch_data_temp = epoch_data_temp-mean(epoch_data_temp(:,((floor(feedback_time)-51):(floor(feedback_time)-1)),:),2, 'omitnan');     
    epoch_data_temp = epoch_data_temp(:,(floor(feedback_time)-51):ceil(feedback_time+(sampling_rate)+51)); %keep only 200ms before feedback starts and 200 ms after feedback stops
    epoch_data_temp=Utilities.downsample(epoch_data_temp,sampling_rate/128);
    data_decoding_ERP(i,:,:) = epoch_data_temp;   
end
end





