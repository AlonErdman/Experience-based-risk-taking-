function [wiggle, HR_percen_all_trial ,percen_of_nan_samples, percen_of_nan_trials_HR] = load_epoch_single_bins_HR_risk_paper(names, data_folder)
%output: reward, pun and neu ERPs, divided for each bin. bins are
%sorted in ascending order according to the chosen paramter.
Nsamples=1101;
Nsubjects=length(names);
HR_percen_all_trial = NaN(Nsubjects,1);
percen_of_nan_samples = NaN(Nsubjects,1);
percen_of_nan_trials_HR = NaN(Nsubjects,1);
wiggle_per_subject = NaN(Nsubjects,1);
for i =1:length(names)
    clear('HR', 'HRoutcome_all', 'ind_na_HR', 'bins_and_trials_single', 'neu_feedback_trials' ,'pun_feedback_trials', 'reward_feedback_trials', 'HR_percen');
    name=names{i};
    filename_HR = dir(strcat(fullfile(data_folder,['subject_' name]),['\' name '_HR.mat']));
    load(strcat(filename_HR(1).folder,'\',filename_HR(1).name), 'HRoutcome_all', 'ind_na_HR', 'HR')
    wiggle(i)=HR.wiggle;
    ind_na_HR(1:324) = [];
    HR_percen_trial = sum(ind_na_HR==0)/length(ind_na_HR);    
    HR_percen_all_trial(i)=HR_percen_trial;
    HRoutcome_all=HRoutcome_all(325:end, :); %remove practice trials
    percen_of_nan_samples(i) = 100 * sum(isnan(HRoutcome_all(:))) / numel(HRoutcome_all);
    rows_all_nan = sum(all(isnan(HRoutcome_all), 2));
    percen_of_nan_trials_HR(i)=rows_all_nan/size(HRoutcome_all,1);
end