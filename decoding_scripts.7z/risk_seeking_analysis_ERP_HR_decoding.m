 %varibles that are required for single bins functions
clear; clc; close all
sampling_rate = 100; %for EEG sampling_rate = 256.03;%EEG
feedback_time = (sampling_rate)*1; %HR; for EEG: feedback_time = (sampling_rate)*0.5; %EEG; assuming epoch data contains 513 samples
data_folder='E:\EEG_HR_new_scripts\all_100_long_epoch_with_HR_after_debugging\Data_Processed';
bins_and_trials_lea = readtable('E:\EEG_HR_new_scripts\summary_table_both_samples.csv'); %bins, trials and paramters (learning model)
names=string(unique(bins_and_trials_lea.subject));
N_electrodes =1 ; %1 for HR; 2 for EEG
%% first part TF:
%TF: get per bin 
[data_decoding_HR] = load_epoch_HR_decoding(names, data_folder, sampling_rate, feedback_time);%or load_epoch_EEG for EEG
[decodability_all, pval_all, predicted_all, regs_all]=HRdecode_group_bins_only_loss(names, data_decoding_HR, data_folder);%or EEGdecode for EEG
%writematrix(decodability_all, 'average_decodability_HR_loss_second.csv');

bins_trials = readtable('summary_table_both_samples.csv');
two_types=1; %one or two type of PE
[bins_trials_deco]=PE_decod_bins_loss_ex_neu(data_decoding_HR, predicted_all, names, data_folder, bins_trials, two_types);%EX_neu=excluding neutral; without ex_neu means use also neurtal outcomes
tab=tabulate(bins_trials_deco.subject);
bins_per_sub=tab(find(tab(:,2)~=0),2);
ps_table = repelem(pval_all, bins_per_sub);
bins_trials_deco.p_decod=ps_table;
%bins_trials_deco.general_deco
writetable(bins_trials_deco,'HR_bothsamples_unsmoothed_nobaseline_20hz_afterdebug_PE_only_loss.csv')

save('decoding_ERP_smoothed_withbaseline_128hz_sample1al1_200pre0post_nofiltered','pval_all','regs_all', 'predicted_all', 'decodability_all', 'data_decoding_ERP')
