function [data_decoding_HR] = load_epoch_HR_decoding(names, data_folder, sampling_rate, feedback_time)
N_trials =4032;
decoding_trial_length = 220; %or 221 for 20hz
data_decoding_HR = NaN(length(names),N_trials,decoding_trial_length);
for i =1:length(names)
    clear('HRoutcome_all');
    name=names{i};
    filename_EEG = dir(strcat(fullfile(data_folder,['subject_' name]),['\' name '_HR.mat']));
    load(strcat(filename_EEG(1).folder,'\',filename_EEG(1).name), 'HRoutcome_all')
    epoch_data =  HRoutcome_all; 
    epoch_data(1:324, :, :) = []; %remove practice trials
    epoch_data=squeeze(epoch_data);
    %epoch_data = smoothdata(epoch_data,2,'movmean' ,10, 'omitnan');
    epoch_data = epoch_data-mean(epoch_data(:,((floor(feedback_time)-99):(floor(feedback_time)-1)),:),2, 'omitnan');  
    epoch_data = epoch_data(:,2:end); %keep from feedback time until 9 sec after
    %epoch_data = epoch_data(:,(feedback_time:(feedback_time+900))); %keep from feedback time until 9 sec after
    epoch_data=Utilities.downsample(epoch_data,sampling_rate/20);   
    data_decoding_HR(i,:,:) = epoch_data;
end
end





