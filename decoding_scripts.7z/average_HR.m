clear; clc;
processing_subject=0;
% Define the data folder
data_folder = 'E:\EEG_HR_new_scripts\all_100_long_epoch_with_HR_after_debugging\Data_Processed';

% Read the bins_and_trials_lea table
bins_and_trials_lea = readtable('G:\My Drive\Lab\risk_seeking_article\risk_seeking_lea_dec_lea_weights\original_risk_lea_weights_dec_lea_both_samples.csv');

% Convert relevant columns to doubles (if they are not already)
bins_and_trials_lea.subject = double(bins_and_trials_lea.subject);
bins_and_trials_lea.from_ms = double(bins_and_trials_lea.from_ms);
bins_and_trials_lea.to_ms = double(bins_and_trials_lea.to_ms);

% Add a new column for the average HR
bins_and_trials_lea.average_HR = nan(height(bins_and_trials_lea), 1);
bins_and_trials_lea.std_intervals = nan(height(bins_and_trials_lea), 1);
bins_and_trials_lea.RMSSD = nan(height(bins_and_trials_lea), 1);
bins_and_trials_lea.PNN50 = nan(height(bins_and_trials_lea), 1);
% Initialize variables for tracking the current subject
current_subject = NaN;
HR = struct();

% Loop over rows in bins_and_trials_lea
for row_idx = 1:height(bins_and_trials_lea)
    % Get the current subject
    subject_id = sprintf('%03d', bins_and_trials_lea.subject(row_idx)); % Convert subject code to 3-digit string

    % If this is a new subject, load their HR file
    if ~strcmp(subject_id, current_subject)
        processing_subject=processing_subject+1;
        disp(processing_subject)
        current_subject = subject_id;
        subject_folder = fullfile(data_folder, ['subject_' subject_id]);
        hr_file = fullfile(subject_folder, [subject_id '_HR.mat']);

        if exist(hr_file, 'file')
            loaded_data = load(hr_file);
            if isfield(loaded_data, 'HR')
                HR = loaded_data.HR;
            else
                error(['HR struct not found in file: ' hr_file]);
            end
        else
            error(['HR file not found for subject: ' subject_id]);
        end
    end

    % Extract times, rates and intervals from the HR struct
    times = double(HR.beattimes(2:end));
    intervals = double(diff(HR.beattimes));
    rates = 60000./intervals;
    
    % Get the time range for this row
    from_time = bins_and_trials_lea.from_ms(row_idx);
    to_time = bins_and_trials_lea.to_ms(row_idx);
    % Find indices in HR.times that fall within the range
    bin_indices = find(times >= from_time & times <= to_time);
    ind_short_all=find(intervals<=2500);
    bin_indices_omit_long=intersect(bin_indices,ind_short_all);
    %bin intervals and rates
    intervals_bin = intervals(bin_indices);
    rates_bin = rates(bin_indices);
    
    %avoid breaks in recording based on long intervals
    ind_short=find(intervals_bin<=2500);
    ind_long=find(intervals_bin>2500);
    ind_long_double = unique([ind_long - 1, ind_long]);
    temp=diff(intervals_bin);
    ind_long_double(ind_long_double < 1 | ind_long_double > length(temp)) = []; % Ensure indices are valid
    %keep only indices of intervals that last less than 2500ms
    intervals_bin_omit_long=intervals_bin(ind_short);
    rates_bin_omit_long=rates_bin(ind_short);
    % Calculate the average HR and variance of intervals within the range and store in the table
    if ~isempty(bin_indices_omit_long)
        % Calculate average HR rate
        bins_and_trials_lea.average_HR(row_idx) = nanmean(rates_bin_omit_long);
        % Calculate std of intervals
        bins_and_trials_lea.std_intervals(row_idx) = nanstd(intervals_bin_omit_long);
        % Calculate RMSSD (Root Mean Square of Successive Differences)
        if length(bin_indices_omit_long) > 1
            successive_differences = diff(intervals_bin);
            successive_differences(ind_long_double) = [];
            bins_and_trials_lea.RMSSD(row_idx) = sqrt(nanmean(successive_differences.^2));
        else
            bins_and_trials_lea.RMSSD(row_idx) = NaN; % Not enough data for RMSSD
        end
        % Calculate PNN50 (Proportion of Successive Differences > 50 ms)
        if length(bin_indices_omit_long) > 1
            successive_differences = diff(intervals_bin);
            successive_differences(ind_long_double) = [];
            pnn50_count = sum(abs(successive_differences) > 50);
            bins_and_trials_lea.PNN50(row_idx) = pnn50_count / (length(successive_differences));
        else
            bins_and_trials_lea.PNN50(row_idx) = NaN; % Not enough data for PNN50
        end
    else
        bins_and_trials_lea.average_HR(row_idx) = NaN; % No valid data in range for HR
        bins_and_trials_lea.std_intervals(row_idx) = NaN; % No valid data in range for intervals
        bins_and_trials_lea.RMSSD(row_idx) = NaN; % No valid data in range for RMSSD
        bins_and_trials_lea.PNN50(row_idx) = NaN; % No valid data in range for PNN50
    end    
end


% Optionally, save the updated table
writetable(bins_and_trials_lea, 'bins_and_trials_lea_with_rate_and_int.csv');
